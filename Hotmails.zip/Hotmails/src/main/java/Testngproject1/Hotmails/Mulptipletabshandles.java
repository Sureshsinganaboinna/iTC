package Testngproject1.Hotmails;

public class Mulptipletabshandles {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
